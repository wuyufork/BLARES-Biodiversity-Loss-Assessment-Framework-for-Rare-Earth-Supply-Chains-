BLARES Vensim model translated to Python using PySD.

Files:
- BLARES.py : translated model
- requirements.txt : minimal dependencies
- run_example.py : example script to run the model and export results

Quick start (recommended in a clean environment):
1) pip install -r requirements.txt
2) python run_example.py

Notes:
- This translation preserves the model structure and equations from BLARES.mdl.
- If your original Vensim model uses external data files (e.g., .vdf/.xlsx), you may need to point PySD to them.
