import pysd

# Load the translated model (or you can read the original .mdl with pysd.read_vensim)
model = pysd.load("BLARES.py")

# Run with default settings
out = model.run()

# Save to CSV
out.to_csv("BLARES_output.csv", index=False)
print("Done. Wrote BLARES_output.csv")
