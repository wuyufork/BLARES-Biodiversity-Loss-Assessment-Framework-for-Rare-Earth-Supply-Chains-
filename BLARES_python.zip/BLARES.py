"""
Python model 'BLARES.py'
Translated using PySD
"""

from pathlib import Path
import numpy as np

from pysd.py_backend.functions import if_then_else
from pysd.py_backend.statefuls import Integ, Delay, Smooth
from pysd import Component

__pysd_version__ = "3.14.3"

__data = {"scope": None, "time": lambda: 0}

_root = Path(__file__).parent


component = Component()

#######################################################################
#                          CONTROL VARIABLES                          #
#######################################################################

_control_vars = {
    "initial_time": lambda: 2000,
    "final_time": lambda: 2060,
    "time_step": lambda: 1,
    "saveper": lambda: time_step(),
}


def _init_outer_references(data):
    for key in data:
        __data[key] = data[key]


@component.add(name="Time")
def time():
    """
    Current time of the model.
    """
    return __data["time"]()


@component.add(
    name="FINAL TIME", units="Year", comp_type="Constant", comp_subtype="Normal"
)
def final_time():
    """
    The final time for the simulation.
    """
    return __data["time"].final_time()


@component.add(
    name="INITIAL TIME", units="Year", comp_type="Constant", comp_subtype="Normal"
)
def initial_time():
    """
    The initial time for the simulation.
    """
    return __data["time"].initial_time()


@component.add(
    name="SAVEPER",
    units="Year",
    limits=(0.0, np.nan),
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"time_step": 1},
)
def saveper():
    """
    The frequency with which output is stored.
    """
    return __data["time"].saveper()


@component.add(
    name="TIME STEP",
    units="Year",
    limits=(2000.0, np.nan),
    comp_type="Constant",
    comp_subtype="Normal",
)
def time_step():
    """
    The time step for the simulation.
    """
    return __data["time"].time_step()


#######################################################################
#                           MODEL VARIABLES                           #
#######################################################################


@component.add(
    name="Population",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_population": 1},
    other_deps={"_integ_population": {"initial": {}, "step": {"population_growth": 1}}},
)
def population():
    return _integ_population()


_integ_population = Integ(
    lambda: population_growth(), lambda: 126743, "_integ_population"
)


@component.add(
    name="Population growth",
    units="Ten thousand people/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"gdp": 1},
)
def population_growth():
    return np.interp(
        gdp(),
        [
            100280.0,
            110863.0,
            121659.0,
            134944.0,
            158000.0,
            200447.0,
            251101.0,
            301755.0,
            352409.0,
            403063.0,
            453716.0,
            504370.0,
            555024.0,
            605429.0,
            654772.0,
            699316.0,
            738499.0,
            773315.0,
            806248.0,
            838101.0,
            868997.0,
            898940.0,
            928585.0,
            959486.0,
            991222.0,
            1020000.0,
            1060000.0,
            1090000.0,
            1120000.0,
            1160000.0,
            1190000.0,
            1230000.0,
            1270000.0,
            1300000.0,
            1340000.0,
            1380000.0,
            1420000.0,
            1460000.0,
            1500000.0,
            1540000.0,
            1580000.0,
            1620000.0,
            1670000.0,
            1710000.0,
            1750000.0,
            1800000.0,
            1840000.0,
            1890000.0,
            1940000.0,
            1980000.0,
            2030000.0,
            2080000.0,
            2130000.0,
            2180000.0,
            2230000.0,
            2280000.0,
            2330000.0,
            2380000.0,
            2440000.0,
            2490000.0,
            2540000.0,
        ],
        [
            957.0,
            884.0,
            826.0,
            774.0,
            761.0,
            768.0,
            692.0,
            681.0,
            673.0,
            648.0,
            641.0,
            825.0,
            1006.0,
            804.0,
            920.0,
            824.0,
            781.0,
            738.0,
            695.0,
            652.0,
            609.0,
            566.0,
            523.0,
            480.0,
            437.0,
            394.0,
            351.0,
            308.0,
            265.0,
            222.0,
            179.0,
            136.0,
            120.0,
            114.0,
            108.0,
            102.0,
            96.0,
            90.0,
            84.0,
            78.0,
            72.0,
            66.0,
            60.0,
            54.0,
            48.0,
            42.0,
            36.0,
            30.0,
            24.0,
            18.0,
            12.0,
            6.0,
            0.0,
            -6.0,
            -12.0,
            -18.0,
            -24.0,
            -30.0,
            -36.0,
            -42.0,
            -48.0,
        ],
    )


@component.add(
    name='"EV production (Total)"',
    units="Ten thousand vehicles/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"time": 1},
)
def ev_production_total():
    return np.interp(
        time(),
        [
            2000.0,
            2001.0,
            2002.0,
            2003.0,
            2004.0,
            2005.0,
            2006.0,
            2007.0,
            2008.0,
            2009.0,
            2010.0,
            2011.0,
            2012.0,
            2013.0,
            2014.0,
            2015.0,
            2016.0,
            2017.0,
            2018.0,
            2019.0,
            2020.0,
            2021.0,
            2022.0,
            2023.0,
            2024.0,
            2025.0,
            2026.0,
            2027.0,
            2028.0,
            2029.0,
            2030.0,
            2031.0,
            2032.0,
            2033.0,
            2034.0,
            2035.0,
            2036.0,
            2037.0,
            2038.0,
            2039.0,
            2040.0,
            2041.0,
            2042.0,
            2043.0,
            2044.0,
            2045.0,
            2046.0,
            2047.0,
            2048.0,
            2049.0,
            2050.0,
            2051.0,
            2052.0,
            2053.0,
            2054.0,
            2055.0,
            2056.0,
            2057.0,
            2058.0,
            2059.0,
            2060.0,
        ],
        [
            0.00000e00,
            0.00000e00,
            0.00000e00,
            0.00000e00,
            0.00000e00,
            0.00000e00,
            0.00000e00,
            0.00000e00,
            0.00000e00,
            5.30000e-01,
            7.20000e-01,
            8.40000e-01,
            1.26000e00,
            1.75000e00,
            7.85000e00,
            3.40500e01,
            5.17000e01,
            7.94000e01,
            1.27000e02,
            1.24200e02,
            1.36600e02,
            3.54500e02,
            7.05800e02,
            9.58700e02,
            1.28880e03,
            1.66280e03,
            1.92530e03,
            1.98009e03,
            2.03131e03,
            2.10092e03,
            2.19097e03,
            2.04476e03,
            2.17651e03,
            2.32602e03,
            2.48903e03,
            2.66024e03,
            2.83396e03,
            3.00478e03,
            3.16832e03,
            3.32180e03,
            3.46432e03,
            2.98882e03,
            3.11346e03,
            3.23230e03,
            3.34714e03,
            3.45928e03,
            3.56920e03,
            3.67653e03,
            3.78026e03,
            3.87915e03,
            3.97223e03,
            3.55252e03,
            3.63368e03,
            3.70938e03,
            3.78019e03,
            3.84684e03,
            3.90992e03,
            3.96963e03,
            4.02579e03,
            4.07797e03,
            4.12577e03,
        ],
    )


@component.add(
    name="EV emission reductions",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "ev_ownership": 1,
        "unit_emission_reduction_fact": 1,
        "ev_rare_earth_content": 1,
    },
)
def ev_emission_reductions():
    return (
        ev_ownership()
        * 10000
        * unit_emission_reduction_fact()
        * ev_rare_earth_content()
    )


@component.add(
    name="WT emission reductions",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "installed_wt": 1,
        "unit_emission_reduction_compared_to_grid": 1,
        "wt_rare_earth_content": 1,
    },
)
def wt_emission_reductions():
    return (
        installed_wt()
        * unit_emission_reduction_compared_to_grid()
        * 10000
        * wt_rare_earth_content()
    )


@component.add(
    name="Increased emissions in the REEs supply chain",
    units="t",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "trade_emissions": 1,
        "production_emissions": 1,
        "recycled_emissions": 1,
    },
)
def increased_emissions_in_the_rees_supply_chain():
    return trade_emissions() + production_emissions() + recycled_emissions() / 1000


@component.add(
    name="Reduction in emissions from the REEs supply chain",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_emission_reductions": 1, "wt_emission_reductions": 1},
)
def reduction_in_emissions_from_the_rees_supply_chain():
    return ev_emission_reductions() + wt_emission_reductions()


@component.add(
    name="Net emissions of the REEs supply chain",
    units="tCO2eq",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_net_emissions_of_the_rees_supply_chain": 1},
    other_deps={
        "_integ_net_emissions_of_the_rees_supply_chain": {
            "initial": {},
            "step": {
                "increased_emissions_in_the_rees_supply_chain": 1,
                "reduction_in_emissions_from_the_rees_supply_chain": 1,
            },
        }
    },
)
def net_emissions_of_the_rees_supply_chain():
    return _integ_net_emissions_of_the_rees_supply_chain()


_integ_net_emissions_of_the_rees_supply_chain = Integ(
    lambda: increased_emissions_in_the_rees_supply_chain()
    - reduction_in_emissions_from_the_rees_supply_chain(),
    lambda: 28470.7,
    "_integ_net_emissions_of_the_rees_supply_chain",
)


@component.add(
    name="Cumulative Active emissions",
    units="tCO2eq",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_cumulative_active_emissions": 1},
    other_deps={
        "_integ_cumulative_active_emissions": {
            "initial": {},
            "step": {
                "net_emissions_of_the_rees_supply_chain": 1,
                "emissions_natural_decay": 1,
            },
        }
    },
)
def cumulative_active_emissions():
    return _integ_cumulative_active_emissions()


_integ_cumulative_active_emissions = Integ(
    lambda: net_emissions_of_the_rees_supply_chain() - emissions_natural_decay(),
    lambda: 28186,
    "_integ_cumulative_active_emissions",
)


@component.add(
    name="emissions Natural Decay",
    units="t/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"cumulative_active_emissions": 1},
)
def emissions_natural_decay():
    return cumulative_active_emissions() / 100


@component.add(
    name="Annual biodiversity loss",
    units="MSAlosshayr/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "biodiversity_loss_caused_by_land_use_change": 1,
        "biodiversity_loss_caused_by_emissions": 1,
    },
)
def annual_biodiversity_loss():
    return (
        biodiversity_loss_caused_by_land_use_change()
        + biodiversity_loss_caused_by_emissions()
    )


@component.add(
    name="Biodiversity loss caused by emissions",
    units="MSAhayr",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"cumulative_active_emissions": 1},
)
def biodiversity_loss_caused_by_emissions():
    return cumulative_active_emissions() * 0.000437


@component.add(
    name="REEs GHG intensity floor ratio",
    units="Dmnl",
    comp_type="Constant",
    comp_subtype="Normal",
)
def rees_ghg_intensity_floor_ratio():
    return 0.05


@component.add(
    name="REEs GHG intensity",
    units="kgCO2e/Kg",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "rees_ghg_intensity_base": 2,
        "rees_ghg_intensity_improvement": 1,
        "rees_ghg_intensity_floor_ratio": 1,
    },
)
def rees_ghg_intensity():
    return float(
        np.maximum(
            rees_ghg_intensity_base() * (1 - rees_ghg_intensity_improvement()),
            rees_ghg_intensity_base() * rees_ghg_intensity_floor_ratio(),
        )
    )


@component.add(
    name="REEs GHG intensity base",
    units="kgCO2e/Kg",
    comp_type="Constant",
    comp_subtype="Normal",
)
def rees_ghg_intensity_base():
    return 14


@component.add(
    name="REEs trade embodied emissions",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"rees_trade_current": 1, "rees_ghg_intensity": 1},
)
def rees_trade_embodied_emissions():
    return -rees_trade_current() * rees_ghg_intensity() / 1000


@component.add(
    name="Production emissions",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "ev_production_domestic_consumption": 1,
        "new_wt_installations": 1,
        "nimh_production": 1,
        "pm_production": 1,
        "rees_ghg_intensity": 1,
        "rees_production": 1,
    },
)
def production_emissions():
    return (
        ev_production_domestic_consumption()
        * 10000
        * (0.167 * 8.05 + 0.167 * 9.21 + 0.667 * 10.94)
        + new_wt_installations() * (0.2 * 10604.1 + 0.8 * 6801.93)
        + nimh_production() * 21.15 / 1000
        + pm_production() * (0.57 * 74.6 + 0.43 * 30.2) / 1000
        + rees_production() * rees_ghg_intensity() / 1000
    )


@component.add(
    name="REEs GHG intensity improvement",
    units="Dmnl",
    comp_type="Constant",
    comp_subtype="Normal",
)
def rees_ghg_intensity_improvement():
    return 0.9


@component.add(
    name="PM trade embodied emissions",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"pm_trade_current": 1},
)
def pm_trade_embodied_emissions():
    return -pm_trade_current() * (0.57 * 74.6 + 0.43 * 30.6) / 1000


@component.add(
    name="Recycling rate cap", units="Dmnl", comp_type="Constant", comp_subtype="Normal"
)
def recycling_rate_cap():
    return 0.6


@component.add(
    name="Recycled REEs",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"solid_waste_containing_rees": 1, "pm_waste_total_waste": 2},
)
def recycled_rees():
    return solid_waste_containing_rees() * float(
        np.minimum(
            pm_waste_total_waste() * 0.24 + (1 - pm_waste_total_waste()) * 0.2, 0.6
        )
    )


@component.add(
    name="REE recyclability rate",
    units="Dmnl",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ree_recyclability_rate_raw": 1, "recycling_rate_cap": 1},
)
def ree_recyclability_rate():
    return float(np.minimum(ree_recyclability_rate_raw(), recycling_rate_cap()))


@component.add(
    name="REE recyclability rate raw",
    units="Dmnl",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"pm_waste_total_waste": 2},
)
def ree_recyclability_rate_raw():
    return pm_waste_total_waste() * 0.24 + (1 - pm_waste_total_waste()) * 0.2


@component.add(
    name="REE allocation factor",
    units="Dmnl",
    comp_type="Constant",
    comp_subtype="Normal",
)
def ree_allocation_factor():
    return 0.034


@component.add(
    name="Occupation losses of mines",
    units="MSAlosshayr/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"rees_production_supply": 1, "ree_allocation_factor": 1},
)
def occupation_losses_of_mines():
    return (
        rees_production_supply() * ree_allocation_factor() * 0.00979257 * 0.0001 * 0.276
    )


@component.add(
    name="Recycled emissions",
    units="Kg CO2e/yr",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"pm_scrap": 1, "nihm_scrap": 1},
)
def recycled_emissions():
    return (pm_scrap() * 12.45 + nihm_scrap() * 9.23) / 1000


@component.add(
    name="NiMH battery",
    units="Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_nimh_battery": 1},
    other_deps={
        "_integ_nimh_battery": {
            "initial": {},
            "step": {"nimh_production": 1, "nihm_scrap": 1},
        }
    },
)
def nimh_battery():
    return _integ_nimh_battery()


_integ_nimh_battery = Integ(
    lambda: nimh_production() - nihm_scrap(), lambda: 255865, "_integ_nimh_battery"
)


@component.add(name="a", units="Dmnl", comp_type="Constant", comp_subtype="Normal")
def a():
    return 1


@component.add(
    name="WT trade current",
    units="Ten thousand KW/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"wt_import": 1, "wt_export": 1, "c": 1},
)
def wt_trade_current():
    return (wt_import() - wt_export()) * c()


@component.add(name="b", units="Dmnl", comp_type="Constant", comp_subtype="Normal")
def b():
    return 1


@component.add(name="c", units="Dmnl", comp_type="Constant", comp_subtype="Normal")
def c():
    return 1


@component.add(
    name="EV trade current",
    units="Ten thousand vehicles/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_import": 1, "ev_export": 1, "c": 1},
)
def ev_trade_current():
    return (ev_import() - ev_export()) * c()


@component.add(
    name="NIMH rare earth content",
    units="Kg/Kg",
    comp_type="Constant",
    comp_subtype="Normal",
)
def nimh_rare_earth_content():
    return 0.047


@component.add(
    name="NIMH trade current",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"nimh_import": 1, "nimh_export": 1, "b": 1},
)
def nimh_trade_current():
    return (nimh_import() - nimh_export()) * 0.3368 * b()


@component.add(
    name="REEs trade current",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"rees_import": 1, "rees_export": 1, "proportion": 1, "a": 1},
)
def rees_trade_current():
    return (rees_import() - rees_export()) * proportion() * a()


@component.add(
    name="PM trade current",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"pm_import": 1, "pm_export": 1, "b": 1},
)
def pm_trade_current():
    return (pm_import() - pm_export()) * 0.35 * b()


@component.add(
    name="WT waste rare earth content",
    units="Kg",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"unit_content_pm": 1, "wt_scrap": 1},
)
def wt_waste_rare_earth_content():
    return (
        unit_content_pm()
        * wt_scrap()
        * (0.2 * 3224 + 0.8 * 594)
        * 0.2875
        * 10000
        / 1000
    )


@component.add(
    name="Installed WT",
    units="Ten thousand KW",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_installed_wt": 1},
    other_deps={
        "_integ_installed_wt": {
            "initial": {},
            "step": {"new_wt_installations": 1, "wt_scrap": 1},
        }
    },
)
def installed_wt():
    return _integ_installed_wt()


_integ_installed_wt = Integ(
    lambda: new_wt_installations() - wt_scrap(), lambda: 6.16041, "_integ_installed_wt"
)


@component.add(
    name='"PM waste / Total waste"',
    units="Dmnl",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "pm_scrap": 1,
        "unit_content_pm": 1,
        "ev_waste_rare_earth_content": 1,
        "wt_waste_rare_earth_content": 1,
    },
)
def pm_waste_total_waste():
    return (
        pm_scrap()
        * unit_content_pm()
        * 0.2875
        / (ev_waste_rare_earth_content() + wt_waste_rare_earth_content())
    )


@component.add(
    name="REEs demand",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"rees_consumption": 1},
)
def rees_demand():
    return rees_consumption()


@component.add(
    name="factor increase 0",
    units="tCO2eq/KW/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"rate_of_change": 1, "unit_emission_reduction_compared_to_grid": 1},
)
def factor_increase_0():
    return rate_of_change() * unit_emission_reduction_compared_to_grid()


@component.add(
    name="PM production",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_production_domestic_consumption": 1, "new_wt_installations": 1},
)
def pm_production():
    return ev_production_domestic_consumption() * 10000 * (
        0.667 * 5 + 0.167 * 3.5 + 0.167 * 1.165
    ) + new_wt_installations() * 10000 / 1000 * (0.2 * 550 + 0.8 * 200)


@component.add(
    name="WT scrap",
    units="Ten thousand KW/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"new_wt_installations": 1, "wt_scrapping_factor": 1},
)
def wt_scrap():
    return new_wt_installations() * wt_scrapping_factor()


@component.add(
    name="EV rare earth content",
    units="Kg/Vehicle",
    comp_type="Constant",
    comp_subtype="Normal",
)
def ev_rare_earth_content():
    return (
        0.667 * 5 * 0.2875
        + 0.167 * 3.5 * 0.2875
        + 0.167 * 1.165 * 0.2875
        + 0.167 * 55 * 0.047
    )


@component.add(
    name="Inventory Turnover Rate",
    units="Dmnl",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"re_supply_and_demand_balance": 1, "rees_demand": 1},
)
def inventory_turnover_rate():
    return re_supply_and_demand_balance() / rees_demand() * 0.01


@component.add(
    name="Biodiversity loss caused by land use change",
    units="MSAlosshayr/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"occupation_losses_of_mines": 1, "wt_deployment_occupancy_loss": 1},
)
def biodiversity_loss_caused_by_land_use_change():
    return occupation_losses_of_mines() + wt_deployment_occupancy_loss()


@component.add(
    name='"Price changes (export)"',
    units="USD/Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rare_earth_price": 1},
)
def price_changes_export():
    return np.interp(
        rare_earth_price(),
        [
            32454.7,
            36101.1,
            48006.9,
            51261.8,
            66559.1,
            122375.0,
            208077.0,
            253266.0,
            284913.0,
            792834.0,
            918013.0,
            920871.0,
            999157.0,
            1080000.0,
            1230000.0,
            1270000.0,
            1340000.0,
            1420000.0,
            1480000.0,
            2410000.0,
            2900000.0,
            3420000.0,
            3810000.0,
            4190000.0,
            4570000.0,
            4940000.0,
            5010000.0,
            5080000.0,
            5120000.0,
            5150000.0,
            5230000.0,
            5300000.0,
            5370000.0,
            5440000.0,
            5500000.0,
            5520000.0,
            5570000.0,
            5610000.0,
            5660000.0,
            5710000.0,
            5750000.0,
            5800000.0,
            5820000.0,
            5850000.0,
            5870000.0,
            5890000.0,
            5900000.0,
            5910000.0,
            5920000.0,
            5920000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
        ],
        [
            -0.26189,
            -0.19712,
            -0.19713,
            -0.19712,
            -0.19712,
            -0.19713,
            -0.20897,
            -0.38072,
            -0.20743,
            -0.45407,
            0.58517,
            0.34736,
            0.98953,
            0.178,
            -0.65142,
            -0.05586,
            -0.23997,
            -0.7536,
            0.5865,
            0.83892,
            0.65762,
            0.59703,
            0.07069,
            0.09956,
            -0.01458,
            -0.59178,
            -0.33247,
            -0.23939,
            -0.16222,
            0.19543,
            0.5855,
            0.66704,
            0.33654,
            0.57641,
            -0.19058,
            0.68781,
            0.4848,
            0.53091,
            0.33505,
            0.01928,
            0.42738,
            0.48877,
            -0.3403,
            0.2822,
            0.418,
            0.3048,
            0.006,
            0.2076,
            0.2608,
            0.2376,
            0.3256,
            0.1955,
            -0.0097,
            0.2508,
            0.3002,
            0.0949,
            0.1717,
            0.2106,
            -0.0374,
            0.1965,
        ],
    )


@component.add(
    name='"Price changes (import)"',
    units="USD/Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rare_earth_price": 1},
)
def price_changes_import():
    return np.interp(
        rare_earth_price(),
        [
            30745.9,
            32454.7,
            37431.0,
            48844.2,
            51261.8,
            92472.3,
            184384.0,
            196139.0,
            226528.0,
            760189.0,
            768999.0,
            789945.0,
            799472.0,
            897759.0,
            1030000.0,
            1140000.0,
            1200000.0,
            1270000.0,
            1290000.0,
            2110000.0,
            2540000.0,
            3020000.0,
            3370000.0,
            3690000.0,
            4140000.0,
            4520000.0,
            4790000.0,
            4860000.0,
            4940000.0,
            5010000.0,
            5080000.0,
            5150000.0,
            5230000.0,
            5300000.0,
            5370000.0,
            5440000.0,
            5520000.0,
            5570000.0,
            5610000.0,
            5660000.0,
            5710000.0,
            5750000.0,
            5800000.0,
            5850000.0,
            5870000.0,
            5890000.0,
            5900000.0,
            5910000.0,
            5920000.0,
            5920000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
            5930000.0,
        ],
        [
            0.0106,
            0.28,
            0.0106,
            0.0106,
            0.0106,
            0.0107,
            0.7558,
            0.5745,
            0.7537,
            -0.2304,
            0.9135,
            -0.1166,
            0.1819,
            -0.3228,
            -0.7489,
            0.738,
            -0.6056,
            -0.0792,
            -0.0618,
            -0.1173,
            0.038,
            -0.0529,
            -0.2788,
            -0.2678,
            -0.3175,
            -0.3907,
            -0.4125,
            -0.4792,
            -0.602,
            -0.5292,
            -0.4969,
            -0.5375,
            -0.2817,
            -0.1176,
            -0.2201,
            -0.1124,
            -0.0631,
            -0.1495,
            -0.1299,
            -0.2125,
            -0.346,
            -0.1733,
            -0.1472,
            -0.2346,
            -0.1771,
            -0.225,
            -0.3514,
            -0.2662,
            -0.2535,
            -0.2436,
            -0.2706,
            -0.3697,
            -0.2648,
            -0.2811,
            -0.3138,
            -0.2268,
            -0.2478,
            -0.358,
            -0.2712,
            -0.2162,
        ],
    )


@component.add(
    name="Effect of Costs on Price",
    units="Dmnl",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "elasticity_of_price_to_costs": 1,
        "traders_desired_in_price": 1,
        "expected_total_production_costs": 1,
    },
)
def effect_of_costs_on_price():
    return float(
        np.abs(
            1
            + elasticity_of_price_to_costs()
            * (expected_total_production_costs() / traders_desired_in_price() - 1)
        )
    )


@component.add(
    name="Effect of Inventory Turnover Rate on Price",
    units="Dmnl",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "perceived_inventory_turnover_rate": 1,
        "sensitivity_of_price_to_inventory": 1,
    },
)
def effect_of_inventory_turnover_rate_on_price():
    return (
        perceived_inventory_turnover_rate() ** sensitivity_of_price_to_inventory()
        + 0.35
    )


@component.add(
    name="Elasticity of Price to Costs",
    units="Dmnl",
    comp_type="Constant",
    comp_subtype="Normal",
)
def elasticity_of_price_to_costs():
    return 0.25


@component.add(
    name="Rare earth price",
    units="RMB/tons",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "effect_of_costs_on_price": 1,
        "effect_of_inventory_turnover_rate_on_price": 1,
        "traders_desired_in_price": 1,
    },
)
def rare_earth_price():
    return (
        effect_of_costs_on_price()
        * effect_of_inventory_turnover_rate_on_price()
        * traders_desired_in_price()
    )


@component.add(
    name="EV export",
    units="Ten thousand vehicles/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_export_prices": 1},
)
def ev_export():
    return np.interp(
        rees_export_prices(),
        [
            2.69569,
            3.04245,
            3.30161,
            3.33036,
            3.51609,
            3.54625,
            3.59385,
            3.74956,
            3.82382,
            3.95609,
            4.11959,
            4.31672,
            4.46491,
            4.51385,
            4.71097,
            4.76903,
            4.88281,
            4.97286,
            5.23475,
            5.43187,
            5.62899,
            5.71269,
            6.41075,
            6.83556,
            7.03207,
            7.04961,
            7.07196,
            7.52778,
            7.61604,
            7.64385,
            7.69982,
            7.78228,
            7.88181,
            7.91534,
            7.92505,
            8.28117,
            8.61988,
            9.15918,
            9.84558,
            10.3436,
            10.8622,
            11.1991,
            11.2441,
            11.6743,
            12.1615,
            12.3424,
            12.7483,
            13.0133,
            13.0285,
            13.1968,
            13.4385,
            13.7181,
            13.9146,
            14.1111,
            14.3076,
            14.5041,
            14.8971,
            15.0936,
            15.2901,
            15.4866,
        ],
        [
            1.02116e-01,
            4.25871e00,
            9.35409e-02,
            1.83834e-01,
            6.80770e-02,
            1.63047e00,
            5.96194e00,
            3.15701e-02,
            1.03304e01,
            2.73724e-01,
            2.87119e-02,
            2.58537e-02,
            1.42264e01,
            2.30000e-02,
            2.01373e-02,
            2.41148e01,
            1.51886e01,
            1.72791e-02,
            1.44209e-02,
            1.15627e-02,
            8.70450e-03,
            1.88055e01,
            1.92866e01,
            2.50976e01,
            1.97677e01,
            2.65787e01,
            2.36165e01,
            2.02488e01,
            2.80598e01,
            2.31354e01,
            2.07299e01,
            2.12110e01,
            2.16921e01,
            2.26543e01,
            2.21732e01,
            2.95409e01,
            3.10220e01,
            3.25031e01,
            3.39842e01,
            3.54653e01,
            3.69464e01,
            3.84275e01,
            3.99086e01,
            4.13897e01,
            4.18708e01,
            4.23519e01,
            4.28330e01,
            4.33141e01,
            4.37952e01,
            4.42763e01,
            4.47574e01,
            4.52385e01,
            4.57196e01,
            4.62007e01,
            4.66818e01,
            4.71629e01,
            4.81251e01,
            4.86062e01,
            4.90873e01,
            4.95684e01,
        ],
    )


@component.add(
    name="EV import",
    units="Ten thousand vehicles/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_import_prices": 1},
)
def ev_import():
    return np.interp(
        rees_import_prices(),
        [
            6.67311,
            6.88931,
            7.10551,
            7.32171,
            7.53791,
            7.75411,
            7.97031,
            8.18651,
            8.40271,
            8.61891,
            8.8754,
            9.13345,
            9.41625,
            9.76375,
            10.0056,
            10.1878,
            10.4139,
            10.5617,
            10.7338,
            11.069,
            11.2807,
            11.4158,
            11.5597,
            11.6234,
            11.734,
            11.9531,
            12.0745,
            12.3687,
            12.894,
            13.3918,
            13.9743,
            14.3823,
            14.7757,
            15.139,
            15.466,
            15.7642,
            16.037,
            16.3115,
            16.488,
            16.4975,
            16.5185,
            16.5917,
            16.8447,
            17.1638,
            17.1744,
            17.185,
            17.465,
            17.4756,
            17.4862,
            17.4968,
            17.5413,
            17.6105,
            17.7484,
            18.2258,
            18.3201,
            18.8066,
            18.8672,
            18.8735,
            18.958,
            19.0447,
            19.4865,
        ],
        [
            4.36112e01,
            4.27570e01,
            4.19028e01,
            4.10486e01,
            4.01944e01,
            3.93402e01,
            3.84860e01,
            3.76318e01,
            3.67776e01,
            3.59234e01,
            3.50692e01,
            3.42150e01,
            3.33608e01,
            3.25066e01,
            3.16524e01,
            3.07982e01,
            2.99440e01,
            2.90898e01,
            2.82356e01,
            2.73814e01,
            2.65272e01,
            2.56730e01,
            2.48188e01,
            2.39646e01,
            2.31104e01,
            2.22562e01,
            2.14020e01,
            2.05478e01,
            1.96936e01,
            1.88394e01,
            1.79852e01,
            1.71310e01,
            1.62768e01,
            1.54226e01,
            1.45684e01,
            1.37142e01,
            1.28600e01,
            1.20058e01,
            1.11516e01,
            1.02974e01,
            1.19262e01,
            1.58306e01,
            7.73480e00,
            5.70111e-03,
            7.57311e-03,
            9.44511e-03,
            1.13171e-02,
            1.31891e-02,
            1.50611e-02,
            1.69331e-02,
            6.88060e00,
            1.88051e-02,
            3.90483e00,
            2.78929e00,
            2.06771e-02,
            1.06789e00,
            4.45877e-02,
            1.79278e-01,
            1.20404e-01,
            6.68816e-02,
            6.12656e-02,
        ],
    )


@component.add(
    name="REEs import",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_import_prices": 1},
)
def rees_import():
    return np.interp(
        rees_import_prices(),
        [
            6.67311,
            7.97031,
            8.18651,
            8.40271,
            8.61891,
            8.8754,
            9.13345,
            9.41625,
            9.76375,
            10.0056,
            10.1878,
            10.4139,
            10.5617,
            10.7338,
            11.069,
            11.2807,
            11.4158,
            11.5597,
            11.6234,
            11.734,
            11.9531,
            12.0745,
            12.3687,
            12.894,
            13.3918,
            13.9743,
            14.3823,
            14.7757,
            15.139,
            15.466,
            15.7642,
            16.037,
            16.3115,
            16.488,
            16.4975,
            16.5185,
            16.5917,
            16.8447,
            17.1638,
            17.1744,
            17.185,
            17.465,
            17.4756,
            17.4862,
            17.4968,
            17.5413,
            17.6105,
            17.7484,
            18.2258,
            18.3201,
            18.8066,
            18.8672,
            18.8735,
            18.958,
            19.0447,
            19.4865,
        ],
        [
            86302500.0,
            85102500.0,
            84902500.0,
            84702500.0,
            84502500.0,
            84302500.0,
            84102500.0,
            83902500.0,
            83702500.0,
            82702500.0,
            81702500.0,
            80702500.0,
            79702500.0,
            78702500.0,
            77702500.0,
            76702500.0,
            75702500.0,
            74702500.0,
            73702500.0,
            72702500.0,
            71702500.0,
            70702500.0,
            69702500.0,
            68702500.0,
            67702500.0,
            66702500.0,
            65702500.0,
            63702500.0,
            61702500.0,
            59702500.0,
            57702500.0,
            55702500.0,
            53702500.0,
            51702500.0,
            49702500.0,
            47702500.0,
            41112500.0,
            69539400.0,
            1413930.0,
            910085.0,
            2368650.0,
            1220970.0,
            2548640.0,
            2264140.0,
            5649730.0,
            34425700.0,
            4937410.0,
            2615480.0,
            10674200.0,
            2987530.0,
            3464430.0,
            3894370.0,
            3668850.0,
            1419480.0,
            1479200.0,
            4007190.0,
        ],
    )


@component.add(
    name="REEs import prices",
    units="USD/Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_rees_import_prices": 1},
    other_deps={
        "_integ_rees_import_prices": {
            "initial": {},
            "step": {"price_changes_import": 1},
        }
    },
)
def rees_import_prices():
    return _integ_rees_import_prices()


_integ_rees_import_prices = Integ(
    lambda: price_changes_import(), lambda: 17.1638, "_integ_rees_import_prices"
)


@component.add(
    name='"WT production (Total)"',
    units="Ten thousand KW/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"gdp": 1},
)
def wt_production_total():
    return np.interp(
        gdp(),
        [
            100280.0,
            110863.0,
            121659.0,
            134944.0,
            158000.0,
            200447.0,
            251101.0,
            301755.0,
            352409.0,
            403063.0,
            453716.0,
            504370.0,
            555024.0,
            605429.0,
            654772.0,
            699316.0,
            738499.0,
            773315.0,
            806248.0,
            838101.0,
            868997.0,
            898940.0,
            928585.0,
            959486.0,
            991222.0,
            1020000.0,
            1060000.0,
            1090000.0,
            1120000.0,
            1160000.0,
            1190000.0,
            1230000.0,
            1270000.0,
            1300000.0,
            1340000.0,
            1380000.0,
            1420000.0,
            1460000.0,
            1500000.0,
            1540000.0,
            1580000.0,
            1620000.0,
            1670000.0,
            1710000.0,
            1750000.0,
            1800000.0,
            1840000.0,
            1890000.0,
            1940000.0,
            1980000.0,
            2030000.0,
            2080000.0,
            2130000.0,
            2180000.0,
            2230000.0,
            2280000.0,
            2330000.0,
            2380000.0,
            2440000.0,
            2490000.0,
            2540000.0,
        ],
        [
            7.70000e00,
            5.70000e00,
            6.60000e00,
            9.80000e00,
            1.97000e01,
            5.07000e01,
            1.28800e02,
            3.31100e02,
            6.15400e02,
            1.38030e03,
            1.89290e03,
            1.78300e03,
            1.41566e03,
            2.11003e03,
            2.15008e03,
            2.92402e03,
            2.55338e03,
            1.96600e03,
            1.71074e03,
            2.31241e03,
            5.50075e03,
            6.96464e03,
            8.85965e03,
            1.07547e04,
            1.16497e04,
            1.25447e04,
            1.34397e04,
            1.43347e04,
            1.52297e04,
            1.61247e04,
            1.70197e04,
            1.79147e04,
            1.82097e04,
            1.85047e04,
            1.87997e04,
            1.90947e04,
            1.93897e04,
            1.96847e04,
            1.99797e04,
            2.02747e04,
            2.05697e04,
            2.08647e04,
            2.11597e04,
            2.14548e04,
            2.17498e04,
            2.20448e04,
            2.21398e04,
            2.22348e04,
            2.23298e04,
            2.24248e04,
            2.25198e04,
            2.26148e04,
            2.17098e04,
            2.08048e04,
            1.98998e04,
            1.95948e04,
            1.92898e04,
            1.89848e04,
            1.86798e04,
            1.83748e04,
            1.80698e04,
        ],
    )


@component.add(
    name="Expected Total Production Costs",
    units="RMB/tons",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"time": 1},
)
def expected_total_production_costs():
    return np.interp(
        time(),
        [
            2000.0,
            2001.0,
            2002.0,
            2003.0,
            2004.0,
            2005.0,
            2006.0,
            2007.0,
            2008.0,
            2009.0,
            2010.0,
            2011.0,
            2012.0,
            2013.0,
            2014.0,
            2015.0,
            2016.0,
            2017.0,
            2018.0,
            2019.0,
            2020.0,
            2021.0,
            2022.0,
            2023.0,
            2024.0,
            2025.0,
            2026.0,
            2027.0,
            2028.0,
            2029.0,
            2030.0,
            2031.0,
            2032.0,
            2033.0,
            2034.0,
            2035.0,
            2036.0,
            2037.0,
            2038.0,
            2039.0,
            2040.0,
            2041.0,
            2042.0,
            2043.0,
            2044.0,
            2045.0,
            2046.0,
            2047.0,
            2048.0,
            2049.0,
            2050.0,
            2051.0,
            2052.0,
            2053.0,
            2054.0,
            2055.0,
            2056.0,
            2057.0,
            2058.0,
            2059.0,
            2060.0,
        ],
        [
            69286.8,
            89173.8,
            57087.9,
            54547.0,
            68379.7,
            84858.7,
            160562.0,
            272057.0,
            199939.0,
            117629.0,
            267103.0,
            276199.0,
            294535.0,
            418836.0,
            394591.0,
            344372.0,
            327333.0,
            423551.0,
            418947.0,
            390206.0,
            424906.0,
            428836.0,
            432767.0,
            436698.0,
            440629.0,
            444559.0,
            448490.0,
            452421.0,
            456351.0,
            460282.0,
            464213.0,
            468143.0,
            472074.0,
            476005.0,
            479935.0,
            483866.0,
            487797.0,
            493728.0,
            499658.0,
            505589.0,
            511520.0,
            517450.0,
            523381.0,
            529312.0,
            535242.0,
            541173.0,
            547104.0,
            550034.0,
            552965.0,
            555896.0,
            558827.0,
            561757.0,
            561757.0,
            561757.0,
            561757.0,
            561757.0,
            561757.0,
            561757.0,
            561757.0,
            561757.0,
            561757.0,
        ],
    )


@component.add(
    name="EV scrap",
    units="Ten thousand vehicles/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_production_domestic_consumption": 1, "ev_scrapping_factor": 1},
)
def ev_scrap():
    return ev_production_domestic_consumption() * ev_scrapping_factor()


@component.add(
    name="REEs export",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_export_prices": 1},
)
def rees_export():
    return np.interp(
        rees_export_prices(),
        [
            2.69569,
            3.04245,
            3.30161,
            3.33036,
            3.51609,
            3.54625,
            3.59385,
            3.74956,
            3.82382,
            3.95609,
            4.11959,
            4.31672,
            4.46491,
            4.51385,
            4.71097,
            4.76903,
            4.88281,
            4.97286,
            5.23475,
            5.43187,
            5.62899,
            5.71269,
            6.41075,
            6.83556,
            7.03207,
            7.04961,
            7.07196,
            7.52778,
            7.61604,
            7.64385,
            7.69982,
            7.78228,
            7.88181,
            7.91534,
            7.92505,
            8.28117,
            8.61988,
            9.15918,
            9.84558,
            10.3436,
            10.8622,
            11.1991,
            11.2441,
            11.6743,
            12.1615,
            12.3424,
            12.7483,
            13.0133,
            13.0285,
            13.1968,
            13.4385,
            13.7181,
            13.9146,
            14.1111,
            14.3076,
            14.5041,
            14.7006,
            14.8971,
            15.0936,
            15.2901,
            15.4866,
        ],
        [
            4.05313e07,
            3.46123e07,
            5.94320e07,
            2.45685e07,
            4.48933e07,
            3.54264e07,
            4.26041e07,
            5.74994e07,
            4.54423e07,
            3.08557e07,
            8.86311e07,
            9.22553e07,
            4.64962e07,
            5.88744e07,
            6.17078e07,
            4.75500e07,
            4.86039e07,
            5.24892e07,
            4.83340e07,
            5.26592e07,
            6.09031e07,
            4.96577e07,
            5.17115e07,
            7.22499e07,
            5.37654e07,
            7.43038e07,
            7.01961e07,
            5.58192e07,
            7.63576e07,
            6.81422e07,
            5.78730e07,
            5.99269e07,
            6.19807e07,
            6.60884e07,
            6.40346e07,
            7.84114e07,
            8.04653e07,
            8.25191e07,
            8.45730e07,
            8.66268e07,
            8.86806e07,
            9.07345e07,
            9.37883e07,
            9.68422e07,
            9.98960e07,
            1.02950e08,
            1.03004e08,
            1.03058e08,
            1.03111e08,
            1.03165e08,
            1.03219e08,
            1.03273e08,
            1.03327e08,
            1.03381e08,
            1.03434e08,
            1.03488e08,
            1.03542e08,
            1.03596e08,
            1.03650e08,
            1.03704e08,
            1.03757e08,
        ],
    )


@component.add(
    name="REEs export prices",
    units="USD/Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_rees_export_prices": 1},
    other_deps={
        "_integ_rees_export_prices": {
            "initial": {},
            "step": {"price_changes_export": 1},
        }
    },
)
def rees_export_prices():
    return _integ_rees_export_prices()


_integ_rees_export_prices = Integ(
    lambda: price_changes_export(), lambda: 5.62899, "_integ_rees_export_prices"
)


@component.add(
    name="NIMH import",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_import_prices": 1},
)
def nimh_import():
    return np.interp(
        rees_import_prices(),
        [
            6.67311,
            7.10551,
            7.53791,
            8.18651,
            8.40271,
            8.61891,
            8.8754,
            9.13345,
            9.41625,
            9.76375,
            10.0056,
            10.1878,
            10.4139,
            10.5617,
            10.7338,
            11.069,
            11.2807,
            11.4158,
            11.5597,
            11.6234,
            11.734,
            11.9531,
            12.0745,
            12.3687,
            12.894,
            13.3918,
            13.9743,
            14.3823,
            14.7757,
            15.139,
            15.466,
            15.7642,
            16.037,
            16.3115,
            16.488,
            16.4975,
            16.5185,
            16.5917,
            16.8447,
            17.1638,
            17.1744,
            17.185,
            17.465,
            17.4756,
            17.4862,
            17.4968,
            17.5413,
            17.6105,
            17.7484,
            18.2258,
            18.3201,
            18.8066,
            18.8672,
            18.8735,
            18.958,
            19.0447,
            19.4865,
        ],
        [
            6193940.0,
            6074050.0,
            5954150.0,
            5774310.0,
            5714360.0,
            5654410.0,
            5594470.0,
            5534520.0,
            5474570.0,
            5414620.0,
            5354680.0,
            5294730.0,
            5234780.0,
            5174840.0,
            5114890.0,
            5054940.0,
            4994990.0,
            4935050.0,
            4875100.0,
            4815150.0,
            4755200.0,
            4695260.0,
            4635310.0,
            4575360.0,
            4515420.0,
            4455470.0,
            4395520.0,
            4335570.0,
            4275630.0,
            4215680.0,
            4155730.0,
            4095780.0,
            4035840.0,
            3975890.0,
            3915940.0,
            3855990.0,
            3999000.0,
            3377230.0,
            3785040.0,
            484638.0,
            578767.0,
            650402.0,
            1149770.0,
            1888250.0,
            2431830.0,
            2794800.0,
            3663230.0,
            3526540.0,
            4575750.0,
            3666580.0,
            4827750.0,
            2687670.0,
            3716500.0,
            3409050.0,
            4044180.0,
            4225030.0,
            4107950.0,
        ],
    )


@component.add(
    name="Time to Adjust Perceived Inventory Turnover",
    units="Year",
    comp_type="Constant",
    comp_subtype="Normal",
)
def time_to_adjust_perceived_inventory_turnover():
    return 1.25


@component.add(
    name="PM import",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_import_prices": 1},
)
def pm_import():
    return np.interp(
        rees_import_prices(),
        [
            6.67311,
            7.10551,
            7.97031,
            8.18651,
            8.40271,
            8.61891,
            8.8754,
            9.13345,
            9.41625,
            9.76375,
            10.0056,
            10.1878,
            10.4139,
            10.5617,
            10.7338,
            11.069,
            11.2807,
            11.4158,
            11.5597,
            11.6234,
            11.734,
            11.9531,
            12.0745,
            12.3687,
            12.894,
            13.3918,
            13.9743,
            14.3823,
            14.7757,
            15.139,
            15.466,
            15.7642,
            16.037,
            16.3115,
            16.488,
            16.4975,
            16.5185,
            16.5917,
            16.8447,
            17.1638,
            17.1744,
            17.185,
            17.465,
            17.4756,
            17.4862,
            17.4968,
            17.5413,
            17.6105,
            17.7484,
            18.2258,
            18.3201,
            18.8066,
            18.8672,
            18.8735,
            18.958,
            19.0447,
            19.4865,
        ],
        [
            6382920.0,
            6268800.0,
            6040550.0,
            5983490.0,
            5926420.0,
            5869360.0,
            5812300.0,
            5755240.0,
            5698170.0,
            5641110.0,
            5584050.0,
            5526990.0,
            5469920.0,
            5312860.0,
            5155800.0,
            4998740.0,
            4841670.0,
            4684610.0,
            4527550.0,
            4370480.0,
            4213420.0,
            4056360.0,
            3899300.0,
            3742230.0,
            3585170.0,
            3528110.0,
            3471050.0,
            3413980.0,
            3356920.0,
            3299860.0,
            3242800.0,
            3185730.0,
            3128670.0,
            3071610.0,
            3014550.0,
            2957480.0,
            3531270.0,
            2843360.0,
            2786300.0,
            380571.0,
            506239.0,
            682732.0,
            754569.0,
            935862.0,
            1122930.0,
            1371170.0,
            2365780.0,
            1656840.0,
            2322220.0,
            2301530.0,
            2015080.0,
            2552800.0,
            1589570.0,
            2305330.0,
            3310490.0,
            3572520.0,
            2280310.0,
        ],
    )


@component.add(
    name="Traders desired in price",
    units="RMB/tons",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"time": 1},
)
def traders_desired_in_price():
    return np.interp(
        time(),
        [
            2000.0,
            2001.0,
            2002.0,
            2003.0,
            2004.0,
            2005.0,
            2006.0,
            2007.0,
            2008.0,
            2009.0,
            2010.0,
            2011.0,
            2012.0,
            2013.0,
            2014.0,
            2015.0,
            2016.0,
            2017.0,
            2018.0,
            2019.0,
            2020.0,
            2021.0,
            2022.0,
            2023.0,
            2024.0,
            2025.0,
            2026.0,
            2027.0,
            2028.0,
            2029.0,
            2030.0,
            2031.0,
            2032.0,
            2033.0,
            2034.0,
            2035.0,
            2036.0,
            2037.0,
            2038.0,
            2039.0,
            2040.0,
            2041.0,
            2042.0,
            2043.0,
            2044.0,
            2045.0,
            2046.0,
            2047.0,
            2048.0,
            2049.0,
            2050.0,
            2051.0,
            2052.0,
            2053.0,
            2054.0,
            2055.0,
            2056.0,
            2057.0,
            2058.0,
            2059.0,
            2060.0,
        ],
        [
            68812.9,
            88563.9,
            56697.4,
            54173.9,
            67912.1,
            84278.3,
            158871.0,
            289525.0,
            248613.0,
            140017.0,
            411331.0,
            488425.0,
            522563.0,
            551874.0,
            552888.0,
            409130.0,
            346785.0,
            417148.0,
            439322.0,
            404181.0,
            430580.0,
            409130.0,
            438580.0,
            442580.0,
            446580.0,
            450580.0,
            458580.0,
            466580.0,
            474580.0,
            482580.0,
            490580.0,
            498580.0,
            506580.0,
            514580.0,
            522580.0,
            530580.0,
            538580.0,
            546580.0,
            550580.0,
            554580.0,
            558580.0,
            562580.0,
            566580.0,
            570580.0,
            574580.0,
            575580.0,
            576580.0,
            576680.0,
            576780.0,
            576880.0,
            576980.0,
            577080.0,
            577180.0,
            577280.0,
            577280.0,
            577280.0,
            577280.0,
            577280.0,
            577280.0,
            577280.0,
            577280.0,
        ],
    )


@component.add(
    name="PM export",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_export_prices": 1},
)
def pm_export():
    return np.interp(
        rees_export_prices(),
        [
            2.69569,
            3.04245,
            3.18043,
            3.30161,
            3.33036,
            3.51609,
            3.54625,
            3.59385,
            3.74956,
            3.82382,
            3.95609,
            4.11959,
            4.31672,
            4.46491,
            4.51385,
            4.71097,
            4.76903,
            4.88281,
            4.97286,
            5.23475,
            5.43187,
            5.62899,
            5.71269,
            6.41075,
            6.83556,
            7.03207,
            7.04961,
            7.07196,
            7.52778,
            7.61604,
            7.64385,
            7.69982,
            7.78228,
            7.88181,
            7.91534,
            7.92505,
            8.28117,
            8.61988,
            9.15918,
            9.84558,
            10.3436,
            10.8622,
            11.1991,
            11.2441,
            11.6743,
            12.1615,
            12.3424,
            12.7483,
            13.0133,
            13.0285,
            13.1968,
            13.4385,
            13.7181,
            14.1111,
            14.3076,
            14.8971,
            15.2901,
            15.4866,
        ],
        [
            19385900.0,
            23297500.0,
            -1842110.0,
            9991600.0,
            16347700.0,
            6477890.0,
            21553300.0,
            26899400.0,
            9583080.0,
            27901800.0,
            18825500.0,
            6893120.0,
            4565240.0,
            28904200.0,
            3557610.0,
            2990410.0,
            29906600.0,
            30909100.0,
            2288030.0,
            1877440.0,
            1558060.0,
            915105.0,
            31911500.0,
            32913900.0,
            40523500.0,
            33916300.0,
            41123500.0,
            39923500.0,
            34918700.0,
            41723500.0,
            39323500.0,
            35921100.0,
            36923500.0,
            37523500.0,
            38723500.0,
            38123500.0,
            42323500.0,
            42923500.0,
            43523500.0,
            44123500.0,
            44623500.0,
            45123500.0,
            45623500.0,
            46123500.0,
            46623500.0,
            47123500.0,
            47623500.0,
            48123500.0,
            48623500.0,
            49123500.0,
            49623500.0,
            49823500.0,
            50023500.0,
            50423500.0,
            50623500.0,
            51223500.0,
            51623500.0,
            51823500.0,
        ],
    )


@component.add(
    name="NIMH export",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_export_prices": 1},
)
def nimh_export():
    return np.interp(
        rees_export_prices(),
        [
            2.69569,
            3.04245,
            3.30161,
            3.33036,
            3.51609,
            3.54625,
            3.59385,
            3.74956,
            3.82382,
            3.95609,
            4.11959,
            4.31672,
            4.46491,
            4.51385,
            4.71097,
            4.76903,
            4.88281,
            4.97286,
            5.23475,
            5.43187,
            5.62899,
            5.71269,
            6.41075,
            6.83556,
            7.03207,
            7.04961,
            7.07196,
            7.52778,
            7.61604,
            7.64385,
            7.69982,
            7.78228,
            7.88181,
            7.91534,
            7.92505,
            8.28117,
            8.61988,
            9.15918,
            9.84558,
            10.3436,
            10.8622,
            11.1991,
            11.2441,
            11.6743,
            12.1615,
            12.3424,
            12.7483,
            13.0133,
            13.0285,
            13.1968,
            13.4385,
            13.7181,
            13.9146,
            14.1111,
            14.3076,
            14.5041,
            14.7006,
            14.8971,
            15.0936,
            15.2901,
            15.4866,
        ],
        [
            24159900.0,
            15299300.0,
            18564100.0,
            30020800.0,
            15979300.0,
            19874200.0,
            21087600.0,
            24224000.0,
            18917000.0,
            16469000.0,
            21020400.0,
            15519500.0,
            18882600.0,
            12603700.0,
            9544910.0,
            17804300.0,
            20462200.0,
            6315260.0,
            4142970.0,
            3707330.0,
            2348120.0,
            20629300.0,
            21419100.0,
            29317300.0,
            22209000.0,
            30107200.0,
            28527500.0,
            22998800.0,
            30897000.0,
            27737700.0,
            23788600.0,
            24578400.0,
            25368200.0,
            26947900.0,
            26158100.0,
            31686800.0,
            32476600.0,
            33266500.0,
            34056300.0,
            34846100.0,
            35635900.0,
            36425700.0,
            37215600.0,
            38005400.0,
            38795200.0,
            39585000.0,
            40374800.0,
            41164700.0,
            41954500.0,
            42744300.0,
            43534100.0,
            44323900.0,
            45113800.0,
            45903600.0,
            46693400.0,
            47483200.0,
            48273100.0,
            49062900.0,
            49852700.0,
            50642500.0,
            51432300.0,
        ],
    )


@component.add(
    name="Cumulative biodiversity loss in China",
    units="MSAlosshayr",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_cumulative_biodiversity_loss_in_china": 1},
    other_deps={
        "_integ_cumulative_biodiversity_loss_in_china": {
            "initial": {},
            "step": {"annual_biodiversity_loss": 1},
        }
    },
)
def cumulative_biodiversity_loss_in_china():
    return _integ_cumulative_biodiversity_loss_in_china()


_integ_cumulative_biodiversity_loss_in_china = Integ(
    lambda: annual_biodiversity_loss(),
    lambda: 22.9575,
    "_integ_cumulative_biodiversity_loss_in_china",
)


@component.add(
    name="Sensitivity of Price to Inventory",
    units="Dmnl",
    comp_type="Constant",
    comp_subtype="Normal",
)
def sensitivity_of_price_to_inventory():
    return -1


@component.add(
    name="WT import",
    units="Ten thousand KW/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_import_prices": 1},
)
def wt_import():
    return np.interp(
        rees_import_prices(),
        [
            6.67311,
            6.88931,
            7.10551,
            7.53791,
            7.75411,
            7.97031,
            8.18651,
            8.40271,
            8.61891,
            8.8754,
            9.13345,
            9.41625,
            9.76375,
            10.0056,
            10.1878,
            10.4139,
            10.5617,
            10.7338,
            11.069,
            11.2807,
            11.4158,
            11.5597,
            11.6234,
            11.734,
            11.9531,
            12.0745,
            12.3687,
            12.894,
            13.3918,
            13.9743,
            14.3823,
            14.7757,
            15.139,
            15.466,
            15.7642,
            16.037,
            16.3115,
            16.488,
            16.4975,
            16.5185,
            16.5917,
            16.8447,
            17.1638,
            17.1744,
            17.185,
            17.465,
            17.4756,
            17.4862,
            17.4968,
            17.5413,
            17.6105,
            17.7484,
            18.2258,
            18.3201,
            18.8066,
            18.8672,
            18.8735,
            18.958,
            19.0447,
            19.4865,
        ],
        [
            4.55416,
            4.45682,
            4.35947,
            4.16478,
            4.06743,
            3.97008,
            3.87273,
            3.77539,
            3.67804,
            3.58069,
            3.48335,
            3.386,
            3.28865,
            3.1913,
            3.09396,
            2.99661,
            2.89926,
            2.80192,
            2.70457,
            2.60722,
            2.50987,
            2.41253,
            2.31518,
            2.21783,
            2.12049,
            2.02314,
            1.92579,
            1.82844,
            1.7311,
            1.63375,
            1.5364,
            1.43906,
            1.34171,
            1.24436,
            1.14701,
            1.04967,
            0.952319,
            0.854972,
            0.883475,
            0.643216,
            0.402956,
            0.5543,
            0.365119,
            0.138102,
            0.102158,
            0.181614,
            0.497546,
            0.923203,
            1.29021,
            0.109725,
            2.09991,
            0.491871,
            0.170263,
            1.11428,
            0.274312,
            0.633756,
            0.340526,
            0.0756724,
            0.860774,
            0.310257,
        ],
    )


@component.add(
    name="WT deployment occupancy loss",
    units="MSAlosshayr/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"installed_wt": 1},
)
def wt_deployment_occupancy_loss():
    return installed_wt() * 407.496 * 0.0149321 * 0.276


@component.add(
    name="Perceived Inventory Turnover Rate",
    units="Dmnl",
    comp_type="Stateful",
    comp_subtype="Smooth",
    depends_on={
        "_smooth_perceived_inventory_turnover_rate": 1,
        "_smooth_perceived_inventory_turnover_rate_1": 1,
    },
    other_deps={
        "_smooth_perceived_inventory_turnover_rate": {
            "initial": {"inventory_turnover_rate": 1},
            "step": {
                "inventory_turnover_rate": 1,
                "time_to_adjust_perceived_inventory_turnover": 1,
            },
        },
        "_smooth_perceived_inventory_turnover_rate_1": {
            "initial": {"inventory_turnover_rate": 1},
            "step": {
                "inventory_turnover_rate": 1,
                "time_to_adjust_perceived_inventory_turnover": 1,
            },
        },
    },
)
def perceived_inventory_turnover_rate():
    return if_then_else(
        _smooth_perceived_inventory_turnover_rate() >= 0.1,
        lambda: _smooth_perceived_inventory_turnover_rate_1(),
        lambda: 0.1,
    )


_smooth_perceived_inventory_turnover_rate = Smooth(
    lambda: inventory_turnover_rate(),
    lambda: time_to_adjust_perceived_inventory_turnover(),
    lambda: inventory_turnover_rate(),
    lambda: 1,
    "_smooth_perceived_inventory_turnover_rate",
)

_smooth_perceived_inventory_turnover_rate_1 = Smooth(
    lambda: inventory_turnover_rate(),
    lambda: time_to_adjust_perceived_inventory_turnover(),
    lambda: inventory_turnover_rate(),
    lambda: 1,
    "_smooth_perceived_inventory_turnover_rate_1",
)


@component.add(
    name="WT export",
    units="Ten thousand KW/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"rees_export_prices": 1},
)
def wt_export():
    return np.interp(
        rees_export_prices(),
        [
            2.69569,
            3.04245,
            3.30161,
            3.33036,
            3.51609,
            3.54625,
            3.59385,
            3.74956,
            3.82382,
            3.95609,
            4.11959,
            4.31672,
            4.46491,
            4.51385,
            4.71097,
            4.76903,
            4.88281,
            4.97286,
            5.23475,
            5.43187,
            5.62899,
            5.71269,
            6.41075,
            6.83556,
            7.03207,
            7.04961,
            7.07196,
            7.52778,
            7.61604,
            7.64385,
            7.69982,
            7.78228,
            7.88181,
            7.91534,
            7.92505,
            8.28117,
            8.61988,
            9.15918,
            9.84558,
            10.3436,
            10.8622,
            11.1991,
            11.2441,
            11.6743,
            12.1615,
            12.3424,
            12.7483,
            13.0133,
            13.0285,
            13.1968,
            13.4385,
            13.7181,
            13.9146,
            14.1111,
            14.3076,
            14.5041,
            14.7006,
            14.8971,
            15.0936,
            15.2901,
            15.4866,
        ],
        [
            7.11586e01,
            1.20747e02,
            1.67990e02,
            1.06101e02,
            6.90870e01,
            1.17977e02,
            4.75658e01,
            9.88898e01,
            7.27325e01,
            1.29547e02,
            1.07491e02,
            2.65780e01,
            6.79027e01,
            8.31072e00,
            7.26455e-01,
            1.24746e02,
            7.43027e01,
            5.48625e-01,
            5.29707e-02,
            3.19716e-01,
            3.97280e-02,
            7.52103e01,
            7.61179e01,
            9.51939e01,
            7.80255e01,
            9.71015e01,
            9.32863e01,
            7.99331e01,
            9.90091e01,
            9.13787e01,
            8.18407e01,
            8.37483e01,
            8.56559e01,
            8.94711e01,
            8.75635e01,
            1.00917e02,
            1.02824e02,
            1.04732e02,
            1.06640e02,
            1.08547e02,
            1.10455e02,
            1.12362e02,
            1.14270e02,
            1.16178e02,
            1.18085e02,
            1.19993e02,
            1.21900e02,
            1.23808e02,
            1.25715e02,
            1.27623e02,
            1.29531e02,
            1.31438e02,
            1.33346e02,
            1.35253e02,
            1.37161e02,
            1.39069e02,
            1.40976e02,
            1.42884e02,
            1.44791e02,
            1.46699e02,
            1.48607e02,
        ],
    )


@component.add(
    name="Carbon emission constraints",
    units="Dmnl",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"china_toal_emissions": 1},
)
def carbon_emission_constraints():
    return np.interp(
        china_toal_emissions(),
        [
            3.21407e09,
            3.36443e09,
            3.60497e09,
            4.24968e09,
            4.89470e09,
            5.50880e09,
            6.11110e09,
            6.62406e09,
            6.90472e09,
            7.56763e09,
            8.42502e09,
            9.27455e09,
            9.59869e09,
            9.77374e09,
            9.77461e09,
            9.85899e09,
            1.00131e10,
            1.00716e10,
            1.01446e10,
            1.04348e10,
            1.07539e10,
        ],
        [
            0.22,
            0.22,
            0.31,
            0.36,
            0.69,
            0.69,
            0.69,
            0.69,
            0.81,
            0.97,
            1.31,
            1.47,
            2.78,
            2.89,
            2.83,
            2.47,
            2.75,
            2.86,
            2.53,
            2.94,
            3.14,
        ],
    )


@component.add(
    name="New WT installations",
    units="Ten thousand KW/Year",
    limits=(0.0, np.nan),
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"wt_production_total": 2, "wt_trade_current": 2},
)
def new_wt_installations():
    return if_then_else(
        wt_production_total() + wt_trade_current() >= 0,
        lambda: wt_production_total() + wt_trade_current(),
        lambda: 5,
    )


@component.add(
    name="China emissions growth",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"china_toal_emissions": 1, "growth_rate_of_co2_in_china": 1},
)
def china_emissions_growth():
    return china_toal_emissions() * growth_rate_of_co2_in_china()


@component.add(
    name="China toal emissions",
    units="tCO2eq",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_china_toal_emissions": 1},
    other_deps={
        "_integ_china_toal_emissions": {
            "initial": {},
            "step": {"china_emissions_growth": 1},
        }
    },
)
def china_toal_emissions():
    return _integ_china_toal_emissions()


_integ_china_toal_emissions = Integ(
    lambda: china_emissions_growth(),
    lambda: 3214070000.0,
    "_integ_china_toal_emissions",
)


@component.add(
    name='"EV production (domestic consumption)"',
    units="Ten thousand vehicles/Year",
    limits=(0.0, np.nan),
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_production_total": 2, "ev_trade_current": 2},
)
def ev_production_domestic_consumption():
    return if_then_else(
        ev_production_total() + ev_trade_current() >= 0,
        lambda: ev_production_total() + ev_trade_current(),
        lambda: 0.06,
    )


@component.add(
    name="EV trade",
    units="Ten thousand vehicles",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_ev_trade": 1},
    other_deps={
        "_integ_ev_trade": {"initial": {}, "step": {"ev_import": 1, "ev_export": 1}}
    },
)
def ev_trade():
    return _integ_ev_trade()


_integ_ev_trade = Integ(
    lambda: ev_import() - ev_export(), lambda: -0.0030034, "_integ_ev_trade"
)


@component.add(
    name="EV trade embodied emissions",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_trade_current": 1},
)
def ev_trade_embodied_emissions():
    return -ev_trade_current() * 10000 * (0.167 * 8.05 + 0.167 * 9.21 + 0.667 * 10.94)


@component.add(
    name="PM scrap",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_scrap": 1, "wt_scrap": 1},
)
def pm_scrap():
    return (
        ev_scrap() * 10000 * (0.667 * 5 + 0.167 * 3.5 + 0.167 * 1.165)
        + wt_scrap() * (0.2 * 3224 + 0.8 * 594) * 10000 / 1000
    )


@component.add(
    name="factor increase",
    units="tCO2eq/Vehicle/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"rate_of_change": 1, "unit_emission_reduction_fact": 1},
)
def factor_increase():
    return rate_of_change() * unit_emission_reduction_fact()


@component.add(
    name="REEs production supply",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"rees_production_supply_total": 1, "proportion": 1},
)
def rees_production_supply():
    return rees_production_supply_total() * proportion() * 10000 * 1000


@component.add(
    name='"REEs production supply (Total)"',
    units="Ten thousand tons/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"time": 1},
)
def rees_production_supply_total():
    return np.interp(
        time(),
        [
            2000.0,
            2001.0,
            2002.0,
            2003.0,
            2004.0,
            2005.0,
            2006.0,
            2007.0,
            2008.0,
            2009.0,
            2010.0,
            2011.0,
            2012.0,
            2013.0,
            2014.0,
            2015.0,
            2016.0,
            2017.0,
            2018.0,
            2019.0,
            2020.0,
            2021.0,
            2022.0,
            2023.0,
            2024.0,
            2025.0,
            2026.0,
            2027.0,
            2028.0,
            2029.0,
            2030.0,
            2031.0,
            2032.0,
            2033.0,
            2034.0,
            2035.0,
            2036.0,
            2037.0,
            2038.0,
            2039.0,
            2040.0,
            2041.0,
            2042.0,
            2043.0,
            2044.0,
            2045.0,
            2046.0,
            2047.0,
            2048.0,
            2049.0,
            2050.0,
            2051.0,
            2052.0,
            2053.0,
            2054.0,
            2055.0,
            2056.0,
            2057.0,
            2058.0,
            2059.0,
            2060.0,
        ],
        [
            7.12,
            7.8,
            8.46,
            9.1,
            9.71,
            10.28,
            10.81,
            11.3,
            11.75,
            12.16,
            12.52,
            12.83,
            13.1,
            13.33,
            13.51,
            13.65,
            13.76,
            13.82,
            13.85,
            13.84,
            13.8,
            16.8,
            21.0,
            25.5,
            27.0,
            27.569,
            28.115,
            28.636,
            29.134,
            29.608,
            30.058,
            30.486,
            30.891,
            31.275,
            31.639,
            31.984,
            32.311,
            32.621,
            32.914,
            33.192,
            33.255,
            33.192,
            33.127,
            33.06,
            32.992,
            32.922,
            32.85,
            32.777,
            32.701,
            32.624,
            32.545,
            32.463,
            32.38,
            32.295,
            32.207,
            32.116,
            32.002,
            31.884,
            31.761,
            31.633,
            31.5,
        ],
    )


@component.add(
    name="REEs slag",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_waste_rare_earth_content": 1, "wt_waste_rare_earth_content": 1},
)
def rees_slag():
    return ev_waste_rare_earth_content() + wt_waste_rare_earth_content()


@component.add(
    name="Growth rate of CO2 in China",
    units="1/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"net_emissions_of_the_rees_supply_chain": 1},
)
def growth_rate_of_co2_in_china():
    return np.interp(
        net_emissions_of_the_rees_supply_chain(),
        [
            -3.14000e09,
            -3.09000e09,
            -3.02000e09,
            -2.97000e09,
            -2.91000e09,
            -2.89000e09,
            -2.80000e09,
            -2.66000e09,
            -2.49000e09,
            -2.34000e09,
            -2.21000e09,
            -2.12000e09,
            -2.07000e09,
            -2.05000e09,
            -2.04000e09,
            -1.99000e09,
            -1.92000e09,
            -1.86000e09,
            -1.81000e09,
            -1.78000e09,
            -1.70000e09,
            -1.55000e09,
            -1.39000e09,
            -1.24000e09,
            -1.10000e09,
            -1.01000e09,
            -9.61000e08,
            -9.41000e08,
            -9.21000e08,
            -8.69000e08,
            -7.96000e08,
            -7.39000e08,
            -6.80000e08,
            -6.49000e08,
            -5.74000e08,
            -4.92000e08,
            -4.64000e08,
            -4.24000e08,
            -3.88000e08,
            -3.62000e08,
            -3.49000e08,
            -3.48000e08,
            -3.38000e08,
            -3.25000e08,
            -3.01000e08,
            -2.86000e08,
            -2.67000e08,
            -2.51000e08,
            -2.28000e08,
            -2.19000e08,
            -2.19000e08,
            -2.18000e08,
            -2.18000e08,
            -2.17000e08,
            -2.15000e08,
            -2.14000e08,
            -2.14000e08,
            -2.11000e08,
            -1.80000e08,
            -1.00000e08,
            7.78627e04,
        ],
        [
            0.001964,
            0.00249817,
            0.00303207,
            0.00356598,
            0.00409989,
            0.0041338,
            0.00416771,
            0.00420161,
            0.00423552,
            0.00426943,
            0.00430334,
            0.00543725,
            0.00657116,
            0.00770506,
            0.00283897,
            0.00797288,
            0.0131068,
            0.0182407,
            0.0203746,
            0.0225085,
            0.0246424,
            0.0267763,
            0.0289102,
            0.0310441,
            0.0331781,
            0.035312,
            0.0374459,
            0.0395798,
            0.0417137,
            0.0428476,
            0.0439815,
            0.0451154,
            0.0462493,
            0.0473832,
            0.0485171,
            0.049651,
            0.0507849,
            0.0519189,
            0.0530528,
            0.133854,
            0.0274216,
            0.0731377,
            0.104857,
            0.114739,
            0.083525,
            0.0703818,
            0.085334,
            0.100975,
            0.103783,
            0.17147,
            0.157431,
            0.230834,
            0.177688,
            0.181983,
            0.183978,
            0.182492,
            0.0916949,
            0.129025,
            0.0979072,
            0.105534,
            0.1055,
        ],
    )


@component.add(
    name="RE supply and demand balance",
    units="Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_re_supply_and_demand_balance": 1},
    other_deps={
        "_integ_re_supply_and_demand_balance": {
            "initial": {},
            "step": {"rees_supply": 1, "rees_demand": 1},
        }
    },
)
def re_supply_and_demand_balance():
    return _integ_re_supply_and_demand_balance()


_integ_re_supply_and_demand_balance = Integ(
    lambda: rees_supply() - rees_demand(),
    lambda: 11379400.0,
    "_integ_re_supply_and_demand_balance",
)


@component.add(
    name="NIHM Scrap",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_scrap": 1},
)
def nihm_scrap():
    return ev_scrap() * 0.167 * 55.5 * 10000


@component.add(
    name="NIMH production",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_production_domestic_consumption": 1},
)
def nimh_production():
    return ev_production_domestic_consumption() * 10000 * 55.5 * 0.167


@component.add(
    name="Solid waste containing REEs",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"rees_slag": 1},
)
def solid_waste_containing_rees():
    return rees_slag()


@component.add(
    name="NIMH trade",
    units="Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_nimh_trade": 1},
    other_deps={
        "_integ_nimh_trade": {
            "initial": {},
            "step": {"nimh_import": 1, "nimh_export": 1},
        }
    },
)
def nimh_trade():
    return _integ_nimh_trade()


_integ_nimh_trade = Integ(
    lambda: (nimh_import() - nimh_export()) * 0.3368,
    lambda: -1863480.0,
    "_integ_nimh_trade",
)


@component.add(
    name="NIMH trade embodied emissions",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"nimh_trade_current": 1},
)
def nimh_trade_embodied_emissions():
    return -nimh_trade_current() * 21.15 / 1000


@component.add(
    name='"NIMH trade supply (REEs)"',
    units="Kg",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"nimh_rare_earth_content": 1, "nimh_trade_current": 1},
)
def nimh_trade_supply_rees():
    return nimh_rare_earth_content() * nimh_trade_current()


@component.add(
    name="WT trade embodied emissions",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"wt_trade_current": 1},
)
def wt_trade_embodied_emissions():
    return -wt_trade_current() * (0.2 * 10604.1 + 0.8 * 6801.93)


@component.add(
    name="PM stock",
    units="Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_pm_stock": 1},
    other_deps={
        "_integ_pm_stock": {"initial": {}, "step": {"pm_production": 1, "pm_scrap": 1}}
    },
)
def pm_stock():
    return _integ_pm_stock()


_integ_pm_stock = Integ(
    lambda: pm_production() - pm_scrap(), lambda: 71164.2, "_integ_pm_stock"
)


@component.add(
    name="PM trade",
    units="Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_pm_trade": 1},
    other_deps={
        "_integ_pm_trade": {"initial": {}, "step": {"pm_import": 1, "pm_export": 1}}
    },
)
def pm_trade():
    return _integ_pm_trade()


_integ_pm_trade = Integ(
    lambda: (pm_import() - pm_export()) * 0.35, lambda: -534534, "_integ_pm_trade"
)


@component.add(
    name="WT rare earth content",
    units="Kg/KW",
    comp_type="Constant",
    comp_subtype="Normal",
)
def wt_rare_earth_content():
    return (0.2 * 3224 + 0.8 * 594) * 0.2875 / 1000


@component.add(
    name='"To be disposed and non-recyclable waste"',
    units="Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_to_be_disposed_and_nonrecyclable_waste": 1},
    other_deps={
        "_integ_to_be_disposed_and_nonrecyclable_waste": {
            "initial": {},
            "step": {"solid_waste_containing_rees": 1, "recycled_rees": 1},
        }
    },
)
def to_be_disposed_and_nonrecyclable_waste():
    return _integ_to_be_disposed_and_nonrecyclable_waste()


_integ_to_be_disposed_and_nonrecyclable_waste = Integ(
    lambda: solid_waste_containing_rees() - recycled_rees(),
    lambda: 264.698,
    "_integ_to_be_disposed_and_nonrecyclable_waste",
)


@component.add(
    name="REEs stocks",
    units="Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_rees_stocks": 1},
    other_deps={
        "_integ_rees_stocks": {
            "initial": {},
            "step": {"rees_production": 1, "recycled_rees": 1, "rees_slag": 1},
        }
    },
)
def rees_stocks():
    return _integ_rees_stocks()


_integ_rees_stocks = Integ(
    lambda: rees_production() + recycled_rees() - rees_slag(),
    lambda: 37326,
    "_integ_rees_stocks",
)


@component.add(
    name="REEs supply",
    units="Kg",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "rees_production_supply": 1,
        "rees_trade_supply": 1,
        "recycled_rees": 1,
    },
)
def rees_supply():
    return rees_production_supply() + rees_trade_supply() + recycled_rees()


@component.add(
    name="REEs consumption",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "ev_production_total": 1,
        "ev_rare_earth_content": 1,
        "wt_production_total": 1,
        "wt_rare_earth_content": 1,
    },
)
def rees_consumption():
    return (
        ev_production_total() * 10000 * ev_rare_earth_content()
        + wt_production_total() * 10000 * wt_rare_earth_content()
    )


@component.add(
    name="REEs trade",
    units="Kg",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_rees_trade": 1},
    other_deps={
        "_integ_rees_trade": {
            "initial": {},
            "step": {"rees_import": 1, "rees_export": 1, "proportion": 1},
        }
    },
)
def rees_trade():
    return _integ_rees_trade()


_integ_rees_trade = Integ(
    lambda: (rees_import() - rees_export()) * proportion(),
    lambda: -59489200.0,
    "_integ_rees_trade",
)


@component.add(
    name="proportion",
    units="Kg/Ten thousand tons",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"time": 1},
)
def proportion():
    return np.interp(
        time(),
        [
            2000.0,
            2001.0,
            2002.0,
            2003.0,
            2004.0,
            2005.0,
            2006.0,
            2007.0,
            2008.0,
            2009.0,
            2010.0,
            2011.0,
            2012.0,
            2013.0,
            2014.0,
            2015.0,
            2016.0,
            2017.0,
            2018.0,
            2019.0,
            2020.0,
            2021.0,
            2022.0,
            2023.0,
            2024.0,
            2025.0,
            2026.0,
            2027.0,
            2028.0,
            2029.0,
            2030.0,
            2031.0,
            2032.0,
            2033.0,
            2034.0,
            2035.0,
            2036.0,
            2037.0,
            2038.0,
            2039.0,
            2040.0,
            2041.0,
            2042.0,
            2043.0,
            2044.0,
            2045.0,
            2046.0,
            2047.0,
            2048.0,
            2049.0,
            2050.0,
            2051.0,
            2052.0,
            2053.0,
            2054.0,
            2055.0,
            2056.0,
            2057.0,
            2058.0,
            2059.0,
            2060.0,
        ],
        [
            0.45,
            0.443,
            0.442,
            0.42,
            0.41,
            0.405,
            0.401,
            0.4,
            0.396,
            0.389,
            0.387,
            0.386,
            0.381,
            0.376,
            0.361,
            0.356,
            0.342,
            0.339,
            0.325,
            0.312,
            0.309,
            0.296,
            0.293,
            0.286,
            0.285,
            0.277,
            0.275,
            0.272,
            0.274,
            0.267,
            0.265,
            0.263,
            0.261,
            0.269,
            0.267,
            0.266,
            0.264,
            0.263,
            0.262,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.261,
            0.26,
            0.259,
            0.259,
            0.257,
            0.257,
            0.257,
            0.256,
        ],
    )


@component.add(
    name="REEs production",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"pm_production": 1, "nimh_production": 1},
)
def rees_production():
    return pm_production() * 0.2875 + nimh_production() * 0.047


@component.add(
    name="Unit emission reduction fact",
    units="tCO2eq/Vehicle",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_unit_emission_reduction_fact": 1},
    other_deps={
        "_integ_unit_emission_reduction_fact": {
            "initial": {},
            "step": {"factor_increase": 1},
        }
    },
)
def unit_emission_reduction_fact():
    return _integ_unit_emission_reduction_fact()


_integ_unit_emission_reduction_fact = Integ(
    lambda: factor_increase(), lambda: 2.01, "_integ_unit_emission_reduction_fact"
)


@component.add(
    name="Trade emissions",
    units="tCO2eq/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "ev_trade_embodied_emissions": 1,
        "nimh_trade_embodied_emissions": 1,
        "pm_trade_embodied_emissions": 1,
        "rees_trade_embodied_emissions": 1,
        "wt_trade_embodied_emissions": 1,
    },
)
def trade_emissions():
    return (
        ev_trade_embodied_emissions()
        + nimh_trade_embodied_emissions()
        + pm_trade_embodied_emissions()
        + rees_trade_embodied_emissions()
        + wt_trade_embodied_emissions()
    )


@component.add(
    name="Unit emission reduction compared to grid",
    units="tCO2eq/KW/yr",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_unit_emission_reduction_compared_to_grid": 1},
    other_deps={
        "_integ_unit_emission_reduction_compared_to_grid": {
            "initial": {},
            "step": {"factor_increase_0": 1},
        }
    },
)
def unit_emission_reduction_compared_to_grid():
    return _integ_unit_emission_reduction_compared_to_grid()


_integ_unit_emission_reduction_compared_to_grid = Integ(
    lambda: factor_increase_0(),
    lambda: 1.25057,
    "_integ_unit_emission_reduction_compared_to_grid",
)


@component.add(
    name="REEs trade supply",
    units="Kg",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={
        "nimh_trade_supply_rees": 1,
        "pm_trade_supply_rees": 1,
        "rees_trade_current": 1,
    },
)
def rees_trade_supply():
    return nimh_trade_supply_rees() + pm_trade_supply_rees() + rees_trade_current()


@component.add(
    name="WT trade",
    units="Ten thousand KW",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_wt_trade": 1},
    other_deps={
        "_integ_wt_trade": {"initial": {}, "step": {"wt_import": 1, "wt_export": 1}}
    },
)
def wt_trade():
    return _integ_wt_trade()


_integ_wt_trade = Integ(
    lambda: wt_import() - wt_export(), lambda: 34.4, "_integ_wt_trade"
)


@component.add(
    name="EV ownership",
    units="Ten thousand vehicles",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_ev_ownership": 1},
    other_deps={
        "_integ_ev_ownership": {
            "initial": {},
            "step": {"ev_production_domestic_consumption": 1, "ev_scrap": 1},
        }
    },
)
def ev_ownership():
    return _integ_ev_ownership()


_integ_ev_ownership = Integ(
    lambda: ev_production_domestic_consumption() - ev_scrap(),
    lambda: 0.0526877,
    "_integ_ev_ownership",
)


@component.add(
    name="EV scrapping factor",
    units="Ten thousand vehicles/Ten thousand vehicles",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"time": 1},
)
def ev_scrapping_factor():
    return np.interp(
        time(),
        [
            2000.0,
            2001.0,
            2002.0,
            2003.0,
            2004.0,
            2005.0,
            2006.0,
            2007.0,
            2008.0,
            2009.0,
            2010.0,
            2011.0,
            2012.0,
            2013.0,
            2014.0,
            2015.0,
            2016.0,
            2017.0,
            2018.0,
            2019.0,
            2020.0,
            2021.0,
            2022.0,
            2023.0,
            2024.0,
            2025.0,
            2026.0,
            2027.0,
            2028.0,
            2030.0,
            2031.0,
            2032.0,
            2033.0,
            2034.0,
            2035.0,
            2036.0,
            2037.0,
            2038.0,
            2039.0,
            2040.0,
            2041.0,
            2042.0,
            2043.0,
            2044.0,
            2045.0,
            2046.0,
            2047.0,
            2048.0,
            2049.0,
            2050.0,
            2051.0,
            2052.0,
            2053.0,
            2054.0,
            2055.0,
            2056.0,
            2057.0,
            2058.0,
            2059.0,
            2060.0,
        ],
        [
            0.213616,
            0.439309,
            0.603965,
            0.702873,
            0.759,
            0.793399,
            0.817417,
            0.835876,
            0.850803,
            0.54213,
            0.584576,
            0.723676,
            0.575491,
            0.576106,
            0.305699,
            0.352712,
            0.50479,
            0.514444,
            0.552882,
            0.743645,
            0.774581,
            0.793399,
            0.817417,
            0.835876,
            0.850803,
            0.54213,
            0.584576,
            0.723676,
            0.575491,
            0.305699,
            0.352712,
            0.50479,
            0.514444,
            0.552882,
            0.743645,
            0.774581,
            0.793399,
            0.817417,
            0.835876,
            0.850803,
            0.54213,
            0.584576,
            0.723676,
            0.575491,
            0.576106,
            0.305699,
            0.352712,
            0.50479,
            0.514444,
            0.552882,
            0.743645,
            0.774581,
            0.793399,
            0.817417,
            0.835876,
            0.850803,
            0.54213,
            0.584576,
            0.723676,
            0.575491,
        ],
    )


@component.add(
    name="EV waste rare earth content",
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"ev_scrap": 2, "unit_content_pm": 1, "unit_content_nimh": 1},
)
def ev_waste_rare_earth_content():
    return (
        ev_scrap()
        * 10000
        * (0.667 * 5 * 0.2875 + 0.167 * 3.5 * 0.2875 + 0.167 * 1.165 * 0.2875)
        * unit_content_pm()
        + ev_scrap() * 0.167 * 55 * 0.047 * 10000 * unit_content_nimh()
    )


@component.add(
    name="Rate of change",
    units="1/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"carbon_emission_reduction_related_rd": 1, "rd_delay": 2},
)
def rate_of_change():
    return ((carbon_emission_reduction_related_rd() - rd_delay()) / rd_delay()) * 0.02


@component.add(
    name='"R&D delay"',
    units="number",
    comp_type="Stateful",
    comp_subtype="Delay",
    depends_on={"_delay_rd_delay": 1},
    other_deps={
        "_delay_rd_delay": {
            "initial": {"carbon_emission_reduction_related_rd": 1},
            "step": {"carbon_emission_reduction_related_rd": 1},
        }
    },
)
def rd_delay():
    return _delay_rd_delay()


_delay_rd_delay = Delay(
    lambda: carbon_emission_reduction_related_rd(),
    lambda: 1,
    lambda: carbon_emission_reduction_related_rd(),
    lambda: 1,
    time_step,
    "_delay_rd_delay",
)


@component.add(
    name="WT scrapping factor",
    units="Ten thousand KW/Ten thousand KW",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"time": 1},
)
def wt_scrapping_factor():
    return np.interp(
        time(),
        [
            2000.0,
            2001.0,
            2002.0,
            2003.0,
            2004.0,
            2005.0,
            2006.0,
            2007.0,
            2008.0,
            2009.0,
            2010.0,
            2011.0,
            2012.0,
            2013.0,
            2014.0,
            2015.0,
            2016.0,
            2017.0,
            2018.0,
            2019.0,
            2020.0,
            2021.0,
            2022.0,
            2023.0,
            2024.0,
            2025.0,
            2026.0,
            2027.0,
            2028.0,
            2029.0,
            2030.0,
            2031.0,
            2032.0,
            2033.0,
            2034.0,
            2035.0,
            2036.0,
            2037.0,
            2038.0,
            2039.0,
            2040.0,
            2041.0,
            2042.0,
            2043.0,
            2044.0,
            2045.0,
            2046.0,
            2047.0,
            2048.0,
            2049.0,
            2050.0,
            2051.0,
            2052.0,
            2053.0,
            2054.0,
            2055.0,
            2056.0,
            2057.0,
            2058.0,
            2059.0,
            2060.0,
        ],
        [
            0.199947,
            0.588297,
            0.737369,
            0.657552,
            0.498189,
            0.391639,
            0.368049,
            0.361694,
            0.421922,
            0.404912,
            0.522562,
            0.765257,
            1.08067,
            0.795637,
            0.855577,
            0.730455,
            0.931206,
            1.217,
            1.29643,
            0.91883,
            0.505183,
            0.361694,
            0.421922,
            0.404912,
            0.522562,
            0.765257,
            1.08067,
            0.795637,
            0.855577,
            0.730455,
            0.931206,
            1.217,
            1.29643,
            0.91883,
            0.505183,
            0.361694,
            0.421922,
            0.404912,
            0.522562,
            0.765257,
            1.08067,
            0.795637,
            0.855577,
            0.730455,
            0.931206,
            1.217,
            1.29643,
            0.91883,
            0.505183,
            0.361694,
            0.421922,
            0.404912,
            0.522562,
            0.765257,
            1.08067,
            0.795637,
            0.855577,
            0.730455,
            0.931206,
            1.217,
            1.29643,
        ],
    )


@component.add(
    name="PM rare earth content",
    units="Kg/Kg",
    comp_type="Constant",
    comp_subtype="Normal",
)
def pm_rare_earth_content():
    return 0.2875


@component.add(
    name='"PM trade supply (REEs)"',
    units="Kg/Year",
    comp_type="Auxiliary",
    comp_subtype="Normal",
    depends_on={"pm_trade_current": 1, "pm_rare_earth_content": 1},
)
def pm_trade_supply_rees():
    return pm_trade_current() * pm_rare_earth_content()


@component.add(
    name='"Unit content (PM)"',
    units="Kg/Ten thousand vehicles",
    comp_type="Constant",
    comp_subtype="Normal",
)
def unit_content_pm():
    return 0.0666667


@component.add(
    name='"Unit content (NIMH)"',
    units="Kg/Ten thousand vehicles",
    comp_type="Constant",
    comp_subtype="Normal",
)
def unit_content_nimh():
    return 0.1


@component.add(
    name="GDP growth",
    units="RMB 100 milliont/Year",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"carbon_emission_constraints": 1},
)
def gdp_growth():
    return np.interp(
        carbon_emission_constraints(),
        [
            0.22,
            0.290654,
            0.33506,
            0.429409,
            0.612514,
            0.69,
            0.69,
            0.69,
            0.709861,
            0.794809,
            0.847088,
            0.890241,
            0.925384,
            0.940546,
            0.949236,
            0.956939,
            0.964606,
            0.973682,
            0.986126,
            0.994389,
            1.00033,
            1.00629,
            1.01225,
            1.01823,
            1.02422,
            1.03022,
            1.03623,
            1.04226,
            1.04829,
            1.05434,
            1.0604,
            1.06647,
            1.07256,
            1.07866,
            1.08476,
            1.09088,
            1.09702,
            1.10316,
            1.10932,
            1.11548,
            1.12166,
            1.12786,
            1.13406,
            1.14028,
            1.14651,
            1.15275,
            1.159,
            1.16527,
            1.17155,
            1.17784,
            1.18414,
            1.19046,
            1.19678,
            1.20312,
            1.20948,
            1.21584,
            1.22222,
        ],
        [
            9715.7,
            10583.0,
            10854.3,
            15704.6,
            24418.2,
            50653.8,
            32119.6,
            25478.7,
            50639.8,
            54383.2,
            50599.9,
            45295.1,
            57536.9,
            85640.8,
            87245.2,
            67234.1,
            27051.8,
            135670.0,
            60970.2,
            65234.1,
            69498.0,
            73761.9,
            78025.8,
            72761.9,
            67498.0,
            62234.1,
            60970.2,
            59706.3,
            58442.4,
            57178.5,
            55914.6,
            54650.7,
            53386.8,
            52122.9,
            50859.0,
            49595.1,
            48331.2,
            47067.3,
            45803.4,
            44539.5,
            43275.6,
            42011.7,
            40747.8,
            39483.9,
            38220.0,
            36956.1,
            35692.2,
            34428.3,
            33164.4,
            31900.5,
            30636.6,
            29372.7,
            28108.8,
            26844.9,
            25581.0,
            24317.1,
            23053.2,
        ],
    )


@component.add(
    name='"Carbon emission reduction related R&D"',
    units="number",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"financial_revenue": 1},
)
def carbon_emission_reduction_related_rd():
    return np.interp(
        financial_revenue(),
        [
            13395.2,
            16386.0,
            18903.6,
            21715.3,
            28486.9,
            31649.3,
            38760.2,
            51321.8,
            61330.4,
            68518.3,
            89874.2,
            103874.0,
            117254.0,
            129210.0,
            140370.0,
            152269.0,
            159605.0,
            172593.0,
            182914.0,
            183360.0,
            190390.0,
            317485.0,
            402978.0,
            469473.0,
            573965.0,
        ],
        [
            17.3,
            15.4,
            26.3,
            21.4,
            49.9,
            84.2,
            117.4,
            130.6,
            195.1,
            293.1,
            493.7,
            552.7,
            562.2,
            651.5,
            689.4,
            813.9,
            1279.6,
            1456.9,
            2126.8,
            1810.0,
            1968.4,
            5037.19,
            7022.5,
            8566.63,
            10993.1,
        ],
    )


@component.add(
    name="GDP",
    units="RMB 100 million",
    comp_type="Stateful",
    comp_subtype="Integ",
    depends_on={"_integ_gdp": 1},
    other_deps={"_integ_gdp": {"initial": {}, "step": {"gdp_growth": 1}}},
)
def gdp():
    return _integ_gdp()


_integ_gdp = Integ(lambda: gdp_growth(), lambda: 100280, "_integ_gdp")


@component.add(
    name="Financial revenue",
    units="RMB 100 million",
    comp_type="Auxiliary",
    comp_subtype="with Lookup",
    depends_on={"gdp": 1},
)
def financial_revenue():
    return np.interp(
        gdp(),
        [
            100280.0,
            110863.0,
            121717.0,
            137422.0,
            161840.0,
            187319.0,
            219439.0,
            270092.0,
            319245.0,
            348518.0,
            412119.0,
            487940.0,
            538580.0,
            592963.0,
            643563.0,
            688858.0,
            746395.0,
            832036.0,
            919281.0,
            986515.0,
            1013570.0,
            1149240.0,
            1210210.0,
            2659560.0,
            3218400.0,
            3847100.0,
        ],
        [
            13395.2,
            16386.0,
            18903.6,
            21715.3,
            26396.5,
            31649.3,
            38760.2,
            51321.8,
            61330.4,
            68518.3,
            83101.5,
            109248.0,
            125953.0,
            140212.0,
            151786.0,
            175878.0,
            187755.0,
            220904.0,
            220904.0,
            238858.0,
            245679.0,
            245673.0,
            260609.0,
            412477.0,
            488471.0,
            573965.0,
        ],
    )
